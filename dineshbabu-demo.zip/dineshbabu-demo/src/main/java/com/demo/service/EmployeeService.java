package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.demo.exception.EmployeeNotFoundException;
import com.demo.model.Employees;
import com.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	
	public ResponseEntity<List<Employees>> searchEmployee(String name){
		if(name.isBlank() || name.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		List<Employees> employees = employeeRepository.findByEmpName(name);
		if(employees.isEmpty()) {
			throw new EmployeeNotFoundException();
		}
		return ResponseEntity.status(HttpStatus.OK).body(employees);
	}
}
