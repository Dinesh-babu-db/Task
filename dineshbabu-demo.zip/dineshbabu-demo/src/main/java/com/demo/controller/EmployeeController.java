package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.repository.EmployeeRepository;
import com.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@GetMapping(value="/search-employee/{name}")
	public ResponseEntity<?> searchEmployee(@PathVariable("name")String name){
		return employeeService.searchEmployee(name);
	}
	
}
