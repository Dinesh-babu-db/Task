package com.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.demo.model.Department;

public interface DepartmentRepository extends CrudRepository<Department, Long>{

}
