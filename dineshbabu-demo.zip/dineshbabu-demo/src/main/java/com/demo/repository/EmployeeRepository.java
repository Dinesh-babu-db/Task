package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.demo.model.Employees;

public interface EmployeeRepository extends CrudRepository<Employees, Long> {

	@Query(value= "select * from employees where name = ?1 order by created_at desc",nativeQuery = true)
	List<Employees> findByEmpName(String name);

}
