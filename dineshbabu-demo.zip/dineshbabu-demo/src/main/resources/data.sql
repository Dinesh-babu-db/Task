
INSERT INTO DEPARTMENT (id, name,created_at,updated_at) VALUES (1, 'Mech',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO DEPARTMENT (id, name,created_at,updated_at) VALUES (2, 'Civil',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO DEPARTMENT (id, name,created_at,updated_at) VALUES (3, 'It',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);

INSERT INTO EMPLOYEES (id, name,department_id,created_at,updated_at) VALUES (1, 'jegan',1,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO EMPLOYEES (id, name,department_id,created_at,updated_at) VALUES (2, 'babu',2,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO EMPLOYEES (id, name,department_id,created_at,updated_at) VALUES (3, 'dinesh',3,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO EMPLOYEES (id, name,department_id,created_at,updated_at) VALUES (4, 'jegan',2,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);
INSERT INTO EMPLOYEES (id, name,department_id,created_at,updated_at) VALUES (5, 'jegan',3,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);

